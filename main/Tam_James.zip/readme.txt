*** AUTHORS *** 
JAMES TAM 998233811

*** REFERENCED LIBRARIES / DATA *** 
- processing.org examples
- GUIDO library example list box menu (heavily modified to match design and functionality of project)
- svg file for the court dl'ed from http://savvastjortjoglou.com/nba-play-by-play-movements.html

*** SYSTEM DESCRIPTION / INSTRUCTIONS *** 
This infovis contains:

	a court view- Shows a populated basketball court(ball, 10 players). Click on toggle to view the path each player and ball takes throughout event.

	side menu- Interact with menu to view different teams, players on a specific team, all players, and most importantly to select a specific game and event. The menu is scrollable, but mouse wheel scroll is kind of slow.

	game info- Home Team vs Visitor Team, who is currently in play according to event. Jersey nubmer and color let's you know which player is which on the court view.

	scrollbar- drag to control view. can scroll backwards and forwards.
